// On crée un objet XMLHttpRequest
let xhr = new XMLHttpRequest();

//on initialise notre requête avec open()
xhr.open("GET", "https://jsonplaceholder.typicode.com/posts/1");

//on veut une réponse un format JSON
// xhr.responseType = "json";

let btn = document.createElement("button");
btn.textContent = "Cliquez moi";
document.body.appendChild(btn);

let p = document.createElement("p");

btn.addEventListener("click", () => {
    xhr.onload = () => {
        let data = JSON.parse(xhr.responseText);
        p.textContent = data.body;
        document.body.appendChild(p);
    }
    //On envoie la requête
    xhr.send();
});




