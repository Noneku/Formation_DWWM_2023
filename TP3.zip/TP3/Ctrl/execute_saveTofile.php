<?php



include "../Modele/functions.php";
saveStudentsToCSVFile($studentList);


?>