<?php

include "../Modele/functions.php";

$studentList = loadStudentsFromFile("../ListeStagiaire.txt");
var_dump($studentList);




//saveStudentsToCSV_File($student_print);







?>